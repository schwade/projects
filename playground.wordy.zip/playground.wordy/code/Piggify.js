module.exports.function = function piggify (sentence) {
  var sentence = sentence.toLowerCase()
  var sentence_split = sentence.split(" ");
  var entencesay = "";
  var i;
  var j;
  

  for (i = 0; i < sentence_split.length; i++){
 	  // For each word in the sentence...
    
    var current_word = sentence_split[i];
    var new_word = "";
	  var breaker = 0;
    var onset = "";

    for (j = 0; j < current_word.length; j++){
          // Take the onset of the word...
      
          if(["a","i","e","o","u","y"].indexOf(current_word[j].toLowerCase()) != -1){
             	new_word += current_word[j];
             	breaker = 1;
          } else if(breaker==1){
          		new_word += current_word[j];
          }else {
                onset += current_word[j];
          }
    }      
    
    // And add it to the end of the word...
    if(onset.length == 0){
      // If there was no onset add "-yay" to the end of the word.
      entencesay += new_word+"yay"+" ";
    } else{
      // If there was an onset add the onset then "ay" to the end of the word.
      entencesay += new_word+onset+"ay"+" ";
    }     

  }
  
// Return the sentence that has been translated into igpay atinlay.
return {entencesay:entencesay}
  
}