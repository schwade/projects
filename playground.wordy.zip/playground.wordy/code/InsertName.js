module.exports.function = function insertName (name) {
  var name = name;
  var new_name = "";
  var breaker = 0;
  var i;
  

  for (i = 0; i < name.length; i++){
      // Iterate throught the name provided to remove any consonants at the start of the name.
      // In this implementation vowels are defined as "a","i","e","o","u", and "y". Once one 
      // of these vowels appears take the remaining part of the name as new_name.
      if (breaker != 0){
          new_name += name[i];
      } else if (["a","i","e","o","u","y"].indexOf(name[i].toLowerCase()) != -1){
          new_name += name[i];
          breaker = 1;
          }
    }
  
  // Insert the original and new_name into the name game lyrics.
  var lyrics = name+ "! " +                                           // Taylor! 
               name + " " + name + " bo-b" + new_name.toLowerCase() + // Taylor Taylor bo-baylor,
               ", bonana fanna fo-f" + new_name.toLowerCase() +       // bonana fanna fo-faylor,
               ", fee fai mo-m" + new_name.toLowerCase() + ". " +     // fee fai mo-maylor.
               name+"!";                                              // Taylor!
  
  // Return the name game lyrics to the user.
  return {lyrics:lyrics}
}