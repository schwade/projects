module.exports.function = function izzlelize (sentence) {
  
  // Words that shouldn't be izzlelized.
  var stopwords = ['ourselves', 'hers', 'between', 'the','yourself', 'but', 'again', 'there', 'about', 'once', 'during', 'out', 'very', 'having', 'with', 'they', 'own', 'an', 'be', 'some', 'for', 'do', 'its', 'yours', 'such', 'into', 'of', 'most', 'itself', 'other', 'off', 'is', 'am', 'or', 'who', 'as', 'from', 'him', 'each', 'the', 'themselves', 'until', 'below', 'are', 'we', 'these', 'your', 'his', 'through', 'don', 'nor', 'me', 'were', 'her', 'more', 'himself', 'this', 'down', 'should', 'our', 'their', 'while', 'above', 'both', 'up', 'to', 'ours', 'had', 'she', 'all', 'no', 'when', 'at', 'any', 'before', 'them', 'same', 'and', 'been', 'have', 'in', 'will', 'on', 'does', 'yourselves', 'then', 'that', 'because', 'what', 'over', 'why', 'so', 'can', 'did', 'not', 'now', 'under', 'he', 'you', 'herself', 'has', 'just', 'where', 'too', 'only', 'myself', 'which', 'those', 'i', 'after', 'few', 'whom', 't', 'being', 'if', 'theirs', 'my', 'against', 'a', 'by', 'doing', 'it', 'how', 'further', 'was', 'here', 'than'];
  
  var sentence = sentence.toLowerCase();
  var sentence_split = sentence.split(" ");
  var sentizzle = "";
  var i;
  var j;
  for (i = 0; i < sentence_split.length; i++){
 	  // Iterate through the words in the sentence.

    var current_word = sentence_split[i];
    
    var new_word = "";
	  var onset = "";
    var first_syllable = 0;
    var stop = 0;
    
    if( stopwords.indexOf(current_word.toLowerCase()) > -1){
      // If the word is in stopwords, add that word to the output sentence

      sentizzle += current_word + " ";
      
    }else if (current_word.length > 1 ){
      // If the word is longer than a single letter, find the first two syllables excluding the second vowel
      // and set that substring as new_word.
            for (j = 0; j < current_word.length; j++){
                  if (stop == 1){
                    
                  } else if (first_syllable==1 && ["a","i","e","o","u"].indexOf(current_word[j-1].toLowerCase()) != -1 && 
                                                  ["a","i","e","o","u","y"].indexOf(current_word[j].toLowerCase()) != -1){
                     new_word += current_word[j]  
                  } else if (first_syllable==1 && ["a","i","e","o","u","y"].indexOf(current_word[j].toLowerCase()) != -1){
                     stop = 1;
                  } else if (first_syllable == 1 && stop == 0){
                    new_word += current_word[j]
                  } else if(["a","i","e","o","u","y"].indexOf(current_word[j].toLowerCase()) != -1){
                      first_syllable = 1;
                      new_word += current_word[j];
                  } else if(first_syllable==0){
                      new_word += current_word[j];
                  }
            }
            // Once you have the new_word, add "-izzle" to the end of it and add it to the output sentence.
            sentizzle += new_word + "izzle "
    
    } else {
    // If the current word is not a stop word and is longer than a single letter, just add it to the output sentence.
    sentizzle += current_word + " ";
      
    }

  }
  
  // Return the outpizzle sentizzle to the user.
  return {sentizzle:sentizzle}
}
